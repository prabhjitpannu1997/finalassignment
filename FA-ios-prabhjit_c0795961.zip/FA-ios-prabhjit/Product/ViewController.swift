//
//  ViewController.swift
//  Product
//
//  Created by FA-ios-prabhjit on 25/05/21.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var tableview:UITableView!
    @IBOutlet weak var add:UIButton!
    @IBOutlet weak var provide:UIButton!
    
    var productbytype:[String:[Item]] = [:]
    var productkeys:[String] = []
    var products:[Item] = []
    var isbyproduct = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.dataSource = self
        tableview.delegate = self
        tableview.separatorStyle = .none
        provide.setTitle("Provider", for: .normal)
        add.setTitle("Add", for: .normal)
        
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        products = []
        productbytype = [:]
        productkeys = []
        fetchData()
    }

    @IBAction func provider()
    {
        if isbyproduct == true{
            provide.setTitle("Product", for: .normal)
        }
        else{
            provide.setTitle("Provider", for: .normal)
        }
        isbyproduct = !isbyproduct
        tableview.reloadData()
    }
    
    @IBAction func additem()
    {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let controller = story.instantiateViewController(identifier: "ProductAddVC") as! ProductAddVC
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    func fetchData() {

        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
         let manageContent = appDelegate.persistentContainer.viewContext
         let fetchData = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")

        do {

            let result = try manageContent.fetch(fetchData)

            for data in result as! [NSManagedObject]{
                var product:Item = Item()
                product.id = data.value(forKeyPath: "id") as! String
                product.name = data.value(forKeyPath: "name") as! String
                product.type = data.value(forKeyPath: "type") as! String
                product.desc = data.value(forKeyPath: "productdetail") as! String
                product.price = data.value(forKeyPath: "price") as! Float
                products.append(product)
                
                 
            }
        }catch {
            print("err")
        }
        
        for item in products
        {
            if productbytype[item.type] != nil{
                productbytype[item.type]?.append(item)
            }
            else{
                productbytype[item.type] = [item]
            }
        }
        for str in productbytype.keys
        {
            productkeys.append(str)
        }
        tableview.reloadData()
    }
}

extension ViewController:UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isbyproduct == true{
          return  products.count
        }
        else{
            return productkeys.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch isbyproduct {
        case true:
            let cell = tableview.dequeueReusableCell(withIdentifier: "ProductCell", for: indexPath) as! ProductCell
            cell.name.text = "product name: " + products[indexPath.row].name
            cell.price.text = "price: " + String(products[indexPath.row].price)
            cell.type.text = "product type: " + products[indexPath.row].type
            
            return cell
        case false:
        let cell = tableview.dequeueReusableCell(withIdentifier: "ProviderCell", for: indexPath) as! ProviderCell
            cell.number.text = "count:" + String(productbytype[productkeys[indexPath.row]]!.count)
            cell.type.text = "type: " + productkeys[indexPath.row]
        
        return cell
       
            
        }
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if isbyproduct == true{
            let story = UIStoryboard(name: "Main", bundle: nil)
            let controller = story.instantiateViewController(identifier: "ProductAddVC") as! ProductAddVC
            controller.isedit = true
            controller.product = products[indexPath.row]
           
            self.navigationController?.pushViewController(controller, animated: true)
        }
        else{
            let story = UIStoryboard(name: "Main", bundle: nil)
            let controller = story.instantiateViewController(identifier: "ViewProductVC") as! ViewProductVC
            controller.type = productkeys[indexPath.row]
            
           
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
    
}
