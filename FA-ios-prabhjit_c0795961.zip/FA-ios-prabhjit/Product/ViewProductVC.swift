//
//  ViewProductVC.swift
//  Product
//
//  Created by FA-ios-prabhjit on 25/05/21.
//

import UIKit
import CoreData

class ViewProductVC: UIViewController,UISearchBarDelegate {
    @IBOutlet weak var search:UISearchBar!
    @IBOutlet weak var tableview:UITableView!
    var type:String = ""
    var products:[Item] = []
    var productsPack:[Item] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.dataSource = self
        tableview.delegate = self
        tableview.separatorStyle = .none
        search.delegate = self
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        products = []
        productsPack = []
        fetch()
        tableview.reloadData()
    }

    func fetch()
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")

        fetchRequest.predicate = NSPredicate(format: "type = %@ ",
                                             type)

        do {

            let result = try context.fetch(fetchRequest)

            for data in result as! [NSManagedObject]{
                var product:Item = Item()
                product.id = data.value(forKeyPath: "id") as! String
                product.name = data.value(forKeyPath: "name") as! String
                product.type = data.value(forKeyPath: "type") as! String
                product.desc = data.value(forKeyPath: "productdetail") as! String
                product.price = data.value(forKeyPath: "price") as! Float
                products.append(product)
                productsPack.append(product)
                
                 
            }
        }catch {
            print("err")
        }
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        products = []
        for item in productsPack
        {
            if item.name.lowercased().contains(searchBar.text?.lowercased() ?? "")
            {
                products.append(item)
            }
        }
        tableview.reloadData()
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        products = productsPack
        tableview.reloadData()
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        products = productsPack
        tableview.reloadData()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {

             
      }
}
extension ViewProductVC:UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
          return  products.count
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
       
            let cell = tableview.dequeueReusableCell(withIdentifier: "ProductCell", for: indexPath) as! ProductCell
            cell.name.text = "product name: " + products[indexPath.row].name
            cell.price.text = "price: " + String(products[indexPath.row].price)
            cell.type.text = "product type: " + products[indexPath.row].type
        return cell

        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
            let story = UIStoryboard(name: "Main", bundle: nil)
            let controller = story.instantiateViewController(identifier: "ProductAddVC") as! ProductAddVC
            controller.isedit = true
            controller.product = products[indexPath.row]
           
            self.navigationController?.pushViewController(controller, animated: true)
        
    }
    
}
