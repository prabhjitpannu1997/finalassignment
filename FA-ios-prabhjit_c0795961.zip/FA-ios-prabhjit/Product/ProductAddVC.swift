//
//  ProductAddVC.swift
//  Product
//
//  Created by FA-ios-prabhjit on 25/05/21.
//

import UIKit
import CoreData

class ProductAddVC: UIViewController {
    @IBOutlet weak var name:UITextField!
    @IBOutlet weak var type:UITextField!
    @IBOutlet weak var price:UITextField!
    @IBOutlet weak var desc:UITextField!
    var isedit = false
    var product:Item = Item()
    override func viewDidLoad() {
        super.viewDidLoad()
    if isedit
     {
        name.text = product.name
        type.text = product.type
        price.text = String(product.price)
        desc.text = product.desc
    }
        // Do any additional setup after loading the view.
    }
    

    func saveData() {

        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}

        let manageContent = appDelegate.persistentContainer.viewContext

        let userEntity = NSEntityDescription.entity(forEntityName: "Product", in: manageContent)!

        let product = NSManagedObject(entity: userEntity, insertInto: manageContent)

        product.setValue(String(Date().timeIntervalSince1970), forKeyPath: "id")
        product.setValue(name.text, forKeyPath: "name")
        product.setValue(desc.text, forKeyPath: "productdetail")
        product.setValue(type.text, forKeyPath: "type")
        product.setValue(Float(price.text ?? "0") ?? 0, forKeyPath: "price")
        
        

        do{
            try manageContent.save()
        }catch let error as NSError {

            print("could not save . \(error), \(error.userInfo)")
        }

        
    }
    
    func edit()
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")

        fetchRequest.predicate = NSPredicate(format: "id = %@ ",
                                             product.id)

        do {
            let results = try context.fetch(fetchRequest) as? [NSManagedObject]
            if results?.count != 0 { // Atleast one was returned

                // In my case, I only updated the first item in results
                results![0].setValue(product.id, forKeyPath: "id")
                results![0].setValue(name.text, forKeyPath: "name")
                results![0].setValue(desc.text, forKeyPath: "productdetail")
                results![0].setValue(type.text, forKeyPath: "type")
                results![0].setValue(Float(price.text ?? "0") ?? 0, forKeyPath: "price")
                
            }
        } catch {
            print("Fetch Failed: \(error)")
        }

        do {
            try context.save()
           }
        catch {
            print("Saving Core Data Failed: \(error)")
        }
    }

@IBAction func add()
{
    if isedit
    {
        edit()
    }
    else{
    saveData()
    }
    self.navigationController?.popViewController(animated: true)
}
}
