//
//  Product.swift
//  Product
//
//  Created byFA-ios-prabhjit on 25/05/21.
//

import Foundation
class Item {
    var name:String = ""
    var price:Float = 0
    var type:String = ""
    var desc:String = ""
    var id:String = ""
}
