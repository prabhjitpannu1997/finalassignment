//
//  Product+CoreDataClass.swift
//  Product
//
//  Created by sushil tiwari on 25/05/21.
//
//

import Foundation
import CoreData

@objc(Product)
public class Product: NSManagedObject {

}
